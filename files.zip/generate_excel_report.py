#!/usr/bin/env python3
"""
Generate comprehensive Excel report from dependency test logs
Includes detailed logs, summary, charts, and recommendations
"""

import json
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.chart import PieChart, BarChart, LineChart, Reference
from openpyxl.utils import get_column_letter
from datetime import datetime
import sys

def load_logs(log_file):
    """Load test logs from JSON file"""
    with open(log_file, 'r') as f:
        data = json.load(f)
    return data['logs'], data['results']

def create_excel_report(logs, results, output_file):
    """Create comprehensive Excel report with formatting and charts"""
    
    wb = Workbook()
    ws = wb.active
    ws.title = 'Summary'
    
    # Define colors and styles
    header_fill = PatternFill(start_color='1F4E78', end_color='1F4E78', fill_type='solid')
    header_font = Font(bold=True, color='FFFFFF', size=12)
    subheader_fill = PatternFill(start_color='D9E1F2', end_color='D9E1F2', fill_type='solid')
    subheader_font = Font(bold=True, color='1F4E78', size=11)
    pass_fill = PatternFill(start_color='C6EFCE', end_color='C6EFCE', fill_type='solid')
    pass_font = Font(color='006100', bold=True)
    fail_fill = PatternFill(start_color='FFC7CE', end_color='FFC7CE', fill_type='solid')
    fail_font = Font(color='9C0006', bold=True)
    warn_fill = PatternFill(start_color='FFEB9C', end_color='FFEB9C', fill_type='solid')
    warn_font = Font(color='9C6500', bold=True)
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    # ===== SUMMARY SHEET =====
    ws.column_dimensions['A'].width = 30
    ws.column_dimensions['B'].width = 40
    
    # Title
    ws['A1'] = 'DEPENDENCY TEST REPORT'
    ws['A1'].font = Font(bold=True, size=16, color='1F4E78')
    ws.merge_cells('A1:B1')
    
    ws['A2'] = f"Generated: {results['summary']['timestamp']}"
    ws['A2'].font = Font(italic=True, size=10)
    ws.merge_cells('A2:B2')
    
    # Summary metrics
    ws['A4'] = 'Test Summary'
    ws['A4'].font = subheader_font
    ws['A4'].fill = subheader_fill
    ws.merge_cells('A4:B4')
    
    summary_items = [
        ('Total Tests', results['summary']['total_tests']),
        ('Passed', results['summary']['passed']),
        ('Failed', results['summary']['failed']),
        ('Warnings', results['summary']['warnings']),
        ('Success Rate', results['summary']['success_rate']),
    ]
    
    row = 5
    for label, value in summary_items:
        ws[f'A{row}'] = label
        ws[f'A{row}'].font = Font(bold=True)
        ws[f'B{row}'] = value
        ws[f'B{row}'].font = Font(size=11)
        ws[f'B{row}'].alignment = Alignment(horizontal='right')
        row += 1
    
    # Category breakdown
    categories = {}
    for log in logs:
        cat = log['category']
        if cat not in categories:
            categories[cat] = {'PASS': 0, 'FAIL': 0, 'WARN': 0}
        categories[cat][log['status']] += 1
    
    ws['A12'] = 'Category Breakdown'
    ws['A12'].font = subheader_font
    ws['A12'].fill = subheader_fill
    ws.merge_cells('A12:D12')
    
    ws['A13'] = 'Category'
    ws['B13'] = 'Passed'
    ws['C13'] = 'Failed'
    ws['D13'] = 'Warnings'
    
    for col in ['A', 'B', 'C', 'D']:
        ws[f'{col}13'].font = header_font
        ws[f'{col}13'].fill = header_fill
        ws[f'{col}13'].alignment = Alignment(horizontal='center')
    
    row = 14
    for cat, counts in sorted(categories.items()):
        ws[f'A{row}'] = cat
        ws[f'B{row}'] = counts['PASS']
        ws[f'C{row}'] = counts['FAIL']
        ws[f'D{row}'] = counts['WARN']
        
        for col in ['B', 'C', 'D']:
            ws[f'{col}{row}'].alignment = Alignment(horizontal='center')
        
        row += 1
    
    # ===== DETAILED LOGS SHEET =====
    ws_logs = wb.create_sheet('Detailed Logs')
    
    # Column headers
    headers = ['Timestamp', 'Category', 'Item', 'Status', 'Message', 'Details']
    for col, header in enumerate(headers, 1):
        cell = ws_logs.cell(row=1, column=col)
        cell.value = header
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center', wrap_text=True)
        cell.border = thin_border
    
    # Column widths
    ws_logs.column_dimensions['A'].width = 20
    ws_logs.column_dimensions['B'].width = 20
    ws_logs.column_dimensions['C'].width = 25
    ws_logs.column_dimensions['D'].width = 12
    ws_logs.column_dimensions['E'].width = 35
    ws_logs.column_dimensions['F'].width = 40
    
    # Add logs
    for row, log in enumerate(logs, 2):
        ws_logs[f'A{row}'] = log['timestamp']
        ws_logs[f'B{row}'] = log['category']
        ws_logs[f'C{row}'] = log['item']
        ws_logs[f'D{row}'] = log['status']
        ws_logs[f'E{row}'] = log['message']
        ws_logs[f'F{row}'] = log['details']
        
        # Apply conditional formatting
        status_cell = ws_logs[f'D{row}']
        if log['status'] == 'PASS':
            status_cell.fill = pass_fill
            status_cell.font = pass_font
        elif log['status'] == 'FAIL':
            status_cell.fill = fail_fill
            status_cell.font = fail_font
        elif log['status'] == 'WARN':
            status_cell.fill = warn_fill
            status_cell.font = warn_font
        
        for col in headers:
            ws_logs[f'{get_column_letter(headers.index(col)+1)}{row}'].border = thin_border
            ws_logs[f'{get_column_letter(headers.index(col)+1)}{row}'].alignment = Alignment(wrap_text=True)
    
    # ===== CHARTS SHEET =====
    ws_charts = wb.create_sheet('Charts & Analytics')
    
    # Overall status pie chart
    ws_charts['A1'] = 'Test Results Overview'
    ws_charts['A1'].font = Font(bold=True, size=14, color='1F4E78')
    
    # Create data for charts
    summary_data = [
        ['Status', 'Count'],
        ['Passed', results['summary']['passed']],
        ['Failed', results['summary']['failed']],
        ['Warnings', results['summary']['warnings']]
    ]
    
    for row, item in enumerate(summary_data, 2):
        ws_charts[f'A{row}'] = item[0]
        ws_charts[f'B{row}'] = item[1]
    
    # Pie chart
    pie = PieChart()
    pie.title = "Test Status Distribution"
    labels = Reference(ws_charts, min_col=1, min_row=2, max_row=4)
    data = Reference(ws_charts, min_col=2, min_row=1, max_row=4)
    pie.add_data(data, titles_from_data=True)
    pie.set_categories(labels)
    ws_charts.add_chart(pie, "D2")
    
    # Category breakdown bar chart
    ws_charts['A10'] = 'Results by Category'
    ws_charts['A10'].font = Font(bold=True, size=12, color='1F4E78')
    
    cat_row = 11
    ws_charts['A11'] = 'Category'
    ws_charts['B11'] = 'Passed'
    ws_charts['C11'] = 'Failed'
    ws_charts['D11'] = 'Warnings'
    
    for col in ['A', 'B', 'C', 'D']:
        ws_charts[f'{col}11'].font = Font(bold=True)
        ws_charts[f'{col}11'].fill = subheader_fill
    
    cat_row = 12
    for cat, counts in sorted(categories.items()):
        ws_charts[f'A{cat_row}'] = cat
        ws_charts[f'B{cat_row}'] = counts['PASS']
        ws_charts[f'C{cat_row}'] = counts['FAIL']
        ws_charts[f'D{cat_row}'] = counts['WARN']
        cat_row += 1
    
    # Bar chart
    bar = BarChart()
    bar.type = "col"
    bar.title = "Tests by Category"
    bar.y_axis.title = 'Count'
    bar.x_axis.title = 'Category'
    
    data = Reference(ws_charts, min_col=2, min_row=11, max_row=cat_row-1, max_col=4)
    cats = Reference(ws_charts, min_col=1, min_row=12, max_row=cat_row-1)
    bar.add_data(data, titles_from_data=True)
    bar.set_categories(cats)
    ws_charts.add_chart(bar, "D15")
    
    # ===== RECOMMENDATIONS SHEET =====
    ws_rec = wb.create_sheet('Recommendations')
    
    ws_rec['A1'] = 'Test Recommendations & Next Steps'
    ws_rec['A1'].font = Font(bold=True, size=14, color='1F4E78')
    
    ws_rec.column_dimensions['A'].width = 20
    ws_rec.column_dimensions['B'].width = 60
    
    failed_items = [log for log in logs if log['status'] == 'FAIL']
    warn_items = [log for log in logs if log['status'] == 'WARN']
    
    if failed_items:
        ws_rec['A3'] = 'CRITICAL FAILURES'
        ws_rec['A3'].font = Font(bold=True, size=12, color='FFFFFF')
        ws_rec['A3'].fill = fail_fill
        ws_rec.merge_cells('A3:B3')
        
        row = 4
        for item in failed_items:
            ws_rec[f'A{row}'] = item['item']
            ws_rec[f'A{row}'].font = Font(bold=True)
            ws_rec[f'B{row}'] = f"{item['message']} - {item['details']}"
            ws_rec[f'B{row}'].alignment = Alignment(wrap_text=True)
            row += 1
    
    if warn_items:
        row = 4 + len(failed_items) + 2
        ws_rec[f'A{row}'] = 'WARNINGS'
        ws_rec[f'A{row}'].font = Font(bold=True, size=12, color='FFFFFF')
        ws_rec[f'A{row}'].fill = warn_fill
        ws_rec.merge_cells(f'A{row}:B{row}')
        
        row += 1
        for item in warn_items:
            ws_rec[f'A{row}'] = item['item']
            ws_rec[f'A{row}'].font = Font(bold=True)
            ws_rec[f'B{row}'] = f"{item['message']} - {item['details']}"
            ws_rec[f'B{row}'].alignment = Alignment(wrap_text=True)
            row += 1
    
    # Add general recommendations
    row = 4 + len(failed_items) + len(warn_items) + 4
    ws_rec[f'A{row}'] = 'GENERAL RECOMMENDATIONS'
    ws_rec[f'A{row}'].font = Font(bold=True, size=12, color='FFFFFF')
    ws_rec[f'A{row}'].fill = subheader_fill
    ws_rec.merge_cells(f'A{row}:B{row}')
    
    recommendations = [
        ('1. Update Missing Tools', 'Install any missing core software and Python libraries using package managers'),
        ('2. Configure API Keys', 'Set up environment variables for OpenAI, Anthropic, and other API keys'),
        ('3. Network Verification', 'Ensure stable internet connection (20+ Mbps) for cloud operations'),
        ('4. Storage Expansion', 'If storage < 128GB, clean up or expand disk space'),
        ('5. Git Configuration', 'Run: git config --global user.name "Your Name" && git config --global user.email "email@example.com"'),
        ('6. Docker Setup', 'If Docker not installed, download from docker.com and follow installation steps'),
        ('7. Admin Rights', 'Ensure full administrator access for package installations'),
        ('8. Environment Variables', 'Add key directories to system PATH for easy access to tools'),
    ]
    
    row += 1
    for title, desc in recommendations:
        ws_rec[f'A{row}'] = title
        ws_rec[f'A{row}'].font = Font(bold=True)
        ws_rec[f'B{row}'] = desc
        ws_rec[f'B{row}'].alignment = Alignment(wrap_text=True)
        row += 1
    
    # ===== HARDWARE DETAILS SHEET =====
    ws_hw = wb.create_sheet('Hardware Details')
    
    ws_hw['A1'] = 'Hardware & System Information'
    ws_hw['A1'].font = Font(bold=True, size=14, color='1F4E78')
    ws_hw.merge_cells('A1:B1')
    
    ws_hw.column_dimensions['A'].width = 25
    ws_hw.column_dimensions['B'].width = 40
    
    hw_logs = [log for log in logs if log['category'] == 'Hardware']
    
    row = 3
    for log in hw_logs:
        ws_hw[f'A{row}'] = log['item']
        ws_hw[f'A{row}'].font = Font(bold=True)
        ws_hw[f'B{row}'] = log['message']
        
        if log['status'] == 'PASS':
            ws_hw[f'A{row}'].fill = pass_fill
        elif log['status'] == 'WARN':
            ws_hw[f'A{row}'].fill = warn_fill
        elif log['status'] == 'FAIL':
            ws_hw[f'A{row}'].fill = fail_fill
        
        row += 1
    
    # Save workbook
    wb.save(output_file)
    print(f"✓ Excel report saved: {output_file}")

def main():
    if len(sys.argv) > 1:
        log_file = sys.argv[1]
    else:
        log_file = '/mnt/user-data/outputs/dependency_logs.json'
    
    output_file = '/mnt/user-data/outputs/Dependency_Test_Report.xlsx'
    
    logs, results = load_logs(log_file)
    create_excel_report(logs, results, output_file)
    print(f"✓ Report generated successfully!")
    print(f"  Logs: {log_file}")
    print(f"  Report: {output_file}")

if __name__ == '__main__':
    main()
