#!/bin/bash

# Dependency Testing Suite - Automated Setup
# For macOS and Linux

echo ""
echo "============================================================"
echo "  Dependency Testing Suite - Setup Script"
echo "============================================================"
echo ""

# Check if Python is installed
echo "[1/4] Checking Python installation..."
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python not found"
    echo "Please install Python 3.11+ using:"
    echo "  macOS: brew install python@3.11"
    echo "  Linux: sudo apt-get install python3.11"
    exit 1
fi
python3 --version
echo ""

# Upgrade pip
echo "[2/4] Upgrading pip..."
python3 -m pip install --upgrade pip
if [ $? -ne 0 ]; then
    echo "WARNING: Could not upgrade pip, continuing anyway..."
fi
echo ""

# Install requirements
echo "[3/4] Installing required Python packages..."
pip3 install -r requirements.txt
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to install requirements"
    exit 1
fi
echo ""

# Make scripts executable
echo "[4a/4] Making scripts executable..."
chmod +x test_dependencies.py
chmod +x generate_excel_report.py
chmod +x run_all_tests.py
echo ""

# Run tests
echo "[4b/4] Running dependency tests..."
python3 run_all_tests.py

echo ""
echo "============================================================"
echo "  Setup Complete!"
echo "============================================================"
echo ""
echo "The Excel report should be available at:"
echo "   Dependency_Test_Report.xlsx"
echo ""
echo "For detailed instructions, see README.md"
echo ""
