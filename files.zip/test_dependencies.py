#!/usr/bin/env python3
"""
Comprehensive Dependency Testing Script for AI/ML Development Environment
Tests all core software, Python libraries, API connectivity, and hardware specs
Generates detailed Excel report with logs and charts
"""

import subprocess
import sys
import json
import psutil
import socket
import platform
import shutil
from pathlib import Path
from datetime import datetime
from packaging import version
import requests
from concurrent.futures import ThreadPoolExecutor
import warnings

warnings.filterwarnings('ignore')

class DependencyTester:
    def __init__(self):
        self.results = {
            'system_info': {},
            'core_software': {},
            'python_libraries': {},
            'api_keys': {},
            'hardware': {},
            'network': {},
            'vm_access': {},
            'summary': {}
        }
        self.logs = []
        self.timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
    def log(self, category, item, status, message, details=''):
        log_entry = {
            'timestamp': self.timestamp,
            'category': category,
            'item': item,
            'status': status,
            'message': message,
            'details': details
        }
        self.logs.append(log_entry)
        status_symbol = '✓' if status == 'PASS' else '✗' if status == 'FAIL' else '⚠'
        print(f"{status_symbol} [{category}] {item}: {message}")
        
    def run_command(self, cmd, shell=False):
        try:
            result = subprocess.run(
                cmd if shell else cmd.split(),
                capture_output=True,
                text=True,
                timeout=10,
                shell=shell
            )
            return result.stdout.strip(), result.returncode, result.stderr.strip()
        except subprocess.TimeoutExpired:
            return '', 1, 'Command timeout'
        except Exception as e:
            return '', 1, str(e)
    
    def test_core_software(self):
        print("\n[1/7] Testing Core Software...")
        software = {
            'python': {'cmd': 'python --version', 'min_version': '3.11'},
            'node': {'cmd': 'node --version', 'min_version': '20.0.0'},
            'git': {'cmd': 'git --version', 'min_version': '0.0.0'},
            'docker': {'cmd': 'docker --version', 'min_version': '0.0.0'},
            'pip': {'cmd': 'pip --version', 'min_version': '0.0.0'},
        }
        
        for name, info in software.items():
            output, code, error = self.run_command(info['cmd'])
            if code == 0:
                ver_str = output.split()[-1].rstrip(',')
                try:
                    ver_obj = version.parse(ver_str)
                    min_ver = version.parse(info['min_version'])
                    if ver_obj >= min_ver:
                        self.log('Core Software', name.upper(), 'PASS', f"v{ver_str} installed", output)
                    else:
                        self.log('Core Software', name.upper(), 'FAIL', f"v{ver_str} < required {info['min_version']}", output)
                except:
                    self.log('Core Software', name.upper(), 'PASS', f"Installed - {output}", output)
            else:
                self.log('Core Software', name.upper(), 'FAIL', 'Not installed or not in PATH', error)
        
        # Check for optional tools
        optional = ['jupyter', 'postman', 'playwright', 'code']
        for tool in optional:
            output, code, error = self.run_command(f'which {tool}', shell=True)
            if code == 0:
                self.log('Core Software', tool.upper(), 'PASS', 'Found in PATH', output)
            else:
                self.log('Core Software', tool.upper(), 'WARN', 'Not found in PATH', 'Optional tool')
    
    def test_python_libraries(self):
        print("\n[2/7] Testing Python Libraries...")
        libraries = [
            'langchain', 'langgraph', 'chromadb', 'faiss-cpu', 'sentence-transformers',
            'ragas', 'promptfoo', 'pytest', 'pydantic', 'openai', 'anthropic',
            'langsmith', 'crewai', 'autogen'
        ]
        
        for lib in libraries:
            output, code, error = self.run_command(f'pip show {lib}')
            if code == 0:
                lines = output.split('\n')
                ver = next((l.split(': ')[1] for l in lines if l.startswith('Version')), 'unknown')
                self.log('Python Libraries', lib, 'PASS', f"v{ver} installed", output)
            else:
                self.log('Python Libraries', lib, 'FAIL', 'Not installed', error)
    
    def test_python_imports(self):
        print("\n[3/7] Testing Python Imports...")
        imports = {
            'langchain': 'LangChain Framework',
            'langgraph': 'LangGraph',
            'chromadb': 'ChromaDB Vector DB',
            'faiss': 'FAISS Vector DB',
            'sentence_transformers': 'Sentence Transformers',
            'ragas': 'RAGAS Evaluation',
            'pydantic': 'Pydantic Validation',
            'openai': 'OpenAI SDK',
            'anthropic': 'Anthropic SDK',
            'langsmith': 'LangSmith',
            'crewai': 'CrewAI',
            'autogen': 'AutoGen',
        }
        
        for module, name in imports.items():
            try:
                __import__(module.replace('-', '_'))
                self.log('Python Imports', module, 'PASS', f'{name} importable', 'Success')
            except ImportError as e:
                self.log('Python Imports', module, 'FAIL', f'Import failed', str(e)[:100])
            except Exception as e:
                self.log('Python Imports', module, 'WARN', 'Import issue', str(e)[:100])
    
    def test_api_keys(self):
        print("\n[4/7] Testing API Keys & Subscriptions...")
        apis = {
            'OPENAI_API_KEY': 'OpenAI',
            'ANTHROPIC_API_KEY': 'Anthropic',
            'LANGSMITH_API_KEY': 'LangSmith',
            'GITHUB_TOKEN': 'GitHub',
        }
        
        for env_var, name in apis.items():
            import os
            key = os.getenv(env_var, '').strip()
            if key:
                masked = key[:8] + '...' + key[-4:] if len(key) > 20 else 'present'
                # Test connectivity for valid API keys
                if name == 'OpenAI' and key:
                    try:
                        headers = {'Authorization': f'Bearer {key}'}
                        resp = requests.get('https://api.openai.com/v1/models', headers=headers, timeout=5)
                        if resp.status_code == 200:
                            self.log('API Keys', name, 'PASS', f'{masked} - Valid and accessible', resp.status_code)
                        else:
                            self.log('API Keys', name, 'FAIL', f'{masked} - Invalid key', resp.status_code)
                    except Exception as e:
                        self.log('API Keys', name, 'WARN', f'{masked} - Check connectivity', str(e)[:50])
                elif name == 'Anthropic' and key:
                    try:
                        headers = {'x-api-key': key}
                        resp = requests.get('https://api.anthropic.com/v1/models', headers=headers, timeout=5)
                        if resp.status_code in [200, 401]:
                            self.log('API Keys', name, 'PASS', f'{masked} - Detected', resp.status_code)
                        else:
                            self.log('API Keys', name, 'FAIL', f'{masked} - Invalid key', resp.status_code)
                    except Exception as e:
                        self.log('API Keys', name, 'WARN', f'{masked} - Check connectivity', str(e)[:50])
                else:
                    self.log('API Keys', name, 'PASS', f'{masked} - Present', 'Configured')
            else:
                self.log('API Keys', name, 'WARN', 'Not configured', 'Environment variable not set')
    
    def test_hardware(self):
        print("\n[5/7] Testing Hardware Specifications...")
        
        # CPU Info
        cpu_count = psutil.cpu_count(logical=True)
        cpu_freq = psutil.cpu_freq()
        cpu_status = 'PASS' if cpu_count >= 4 else 'WARN'
        self.log('Hardware', 'CPU', cpu_status, f"{cpu_count} cores @ {cpu_freq.current:.2f} MHz", f"Physical: {psutil.cpu_count(logical=False)}")
        
        # RAM Info
        ram = psutil.virtual_memory()
        ram_gb = ram.total / (1024**3)
        ram_status = 'PASS' if ram_gb >= 16 else 'FAIL' if ram_gb < 8 else 'WARN'
        self.log('Hardware', 'Memory', ram_status, f"{ram_gb:.2f} GB total", f"Available: {ram.available/(1024**3):.2f} GB")
        
        # Storage Info
        disk = psutil.disk_usage('/')
        disk_free_gb = disk.free / (1024**3)
        disk_status = 'PASS' if disk_free_gb >= 128 else 'FAIL' if disk_free_gb < 50 else 'WARN'
        self.log('Hardware', 'Storage', disk_status, f"{disk_free_gb:.2f} GB free", f"Total: {disk.total/(1024**3):.2f} GB")
        
        # Platform
        self.log('Hardware', 'Platform', 'PASS', f"{platform.system()} {platform.release()}", platform.processor())
    
    def test_network(self):
        print("\n[6/7] Testing Network Connectivity...")
        
        # Basic connectivity
        endpoints = {
            'api.openai.com': 'OpenAI API',
            'api.anthropic.com': 'Anthropic API',
            'api.github.com': 'GitHub API',
            'registry.npmjs.org': 'NPM Registry',
            'pypi.org': 'PyPI Repository',
        }
        
        for host, name in endpoints.items():
            try:
                socket.gethostbyname(host)
                self.log('Network', host, 'PASS', f'{name} - Accessible', 'DNS resolution OK')
            except socket.gaierror:
                self.log('Network', host, 'FAIL', f'{name} - DNS failed', 'Cannot resolve hostname')
        
        # Bandwidth test
        try:
            import speedtest
            st = speedtest.Speedtest()
            st.get_best_servers()
            download = st.download() / 1_000_000  # Convert to Mbps
            upload = st.upload() / 1_000_000
            bandwidth_status = 'PASS' if download >= 20 else 'WARN'
            self.log('Network', 'Bandwidth', bandwidth_status, f"Download: {download:.2f} Mbps, Upload: {upload:.2f} Mbps", 'Speed test')
        except:
            # Try simple connectivity test
            try:
                resp = requests.get('https://www.google.com', timeout=5)
                self.log('Network', 'Connectivity', 'PASS', 'Internet access available', resp.status_code)
            except:
                self.log('Network', 'Connectivity', 'FAIL', 'No internet access', 'Cannot reach external servers')
    
    def test_vm_access(self):
        print("\n[7/7] Testing VM Access & Permissions...")
        
        # Admin rights check
        import os
        if os.name == 'nt':  # Windows
            try:
                import ctypes
                is_admin = ctypes.windll.shell.IsUserAnAdmin()
                status = 'PASS' if is_admin else 'FAIL'
                self.log('VM Access', 'Admin Rights', status, f'Administrator: {is_admin}', 'Windows admin check')
            except:
                self.log('VM Access', 'Admin Rights', 'WARN', 'Could not determine admin status', 'ctypes check failed')
        else:
            uid = os.getuid()
            status = 'PASS' if uid == 0 else 'WARN'
            self.log('VM Access', 'Admin Rights', status, f'UID: {uid} (Root: {uid == 0})', 'Unix permission check')
        
        # File write permissions
        test_dir = Path.home() / '.dependency_test'
        try:
            test_dir.mkdir(exist_ok=True)
            test_file = test_dir / 'test.txt'
            test_file.write_text('test')
            test_file.unlink()
            self.log('VM Access', 'Write Permissions', 'PASS', 'Can write to home directory', str(test_dir))
        except Exception as e:
            self.log('VM Access', 'Write Permissions', 'FAIL', 'Cannot write to home directory', str(e)[:50])
        
        # Git configuration
        git_user, git_code, git_err = self.run_command('git config user.name')
        git_email, _, _ = self.run_command('git config user.email')
        if git_code == 0 and git_user:
            self.log('VM Access', 'Git Config', 'PASS', f'User: {git_user}, Email: {git_email}', 'Git configured')
        else:
            self.log('VM Access', 'Git Config', 'WARN', 'Git not configured', 'Run: git config --global user.name')
    
    def generate_summary(self):
        print("\n[Summary] Calculating results...")
        
        pass_count = sum(1 for log in self.logs if log['status'] == 'PASS')
        fail_count = sum(1 for log in self.logs if log['status'] == 'FAIL')
        warn_count = sum(1 for log in self.logs if log['status'] == 'WARN')
        total_count = len(self.logs)
        
        self.results['summary'] = {
            'total_tests': total_count,
            'passed': pass_count,
            'failed': fail_count,
            'warnings': warn_count,
            'success_rate': f"{(pass_count/total_count*100):.1f}%" if total_count > 0 else "0%",
            'timestamp': self.timestamp
        }
        
        print(f"\n{'='*60}")
        print(f"SUMMARY - {self.timestamp}")
        print(f"{'='*60}")
        print(f"Total Tests: {total_count}")
        print(f"✓ Passed:    {pass_count}")
        print(f"✗ Failed:    {fail_count}")
        print(f"⚠ Warnings:  {warn_count}")
        print(f"Success Rate: {self.results['summary']['success_rate']}")
        print(f"{'='*60}\n")
    
    def run_all_tests(self):
        print(f"\n{'='*60}")
        print(f"Dependency Testing Suite Started - {self.timestamp}")
        print(f"{'='*60}")
        
        self.test_core_software()
        self.test_python_libraries()
        self.test_python_imports()
        self.test_api_keys()
        self.test_hardware()
        self.test_network()
        self.test_vm_access()
        self.generate_summary()
        
        return self.logs, self.results

def main():
    tester = DependencyTester()
    logs, results = tester.run_all_tests()
    
    # Save logs as JSON
    with open('/mnt/user-data/outputs/dependency_logs.json', 'w') as f:
        json.dump({'logs': logs, 'results': results}, f, indent=2)
    
    print("\n✓ Logs saved to /mnt/user-data/outputs/dependency_logs.json")
    return logs, results

if __name__ == '__main__':
    logs, results = main()
