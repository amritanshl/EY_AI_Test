# Installation & Setup Guide
## Dependency Testing Suite for AI/ML Development Environment

---

## 📦 What You Get

This package contains everything needed to test your development environment:

```
├── test_dependencies.py          ← Core testing script
├── generate_excel_report.py      ← Excel report generator
├── run_all_tests.py              ← Master orchestration script
├── requirements.txt              ← Python dependencies
├── setup.bat                     ← Windows automated setup
├── setup.sh                      ← macOS/Linux automated setup
├── README.md                     ← Comprehensive documentation
└── INSTALL.md                    ← This file
```

---

## 🚀 Quick Installation (3 Steps)

### For Windows:
```cmd
# 1. Open Command Prompt or PowerShell
# 2. Navigate to the directory with the scripts
cd C:\path\to\test\scripts

# 3. Run setup
setup.bat
```

### For macOS/Linux:
```bash
# 1. Open Terminal
# 2. Navigate to the directory with the scripts
cd /path/to/test/scripts

# 3. Make setup script executable
chmod +x setup.sh

# 4. Run setup
./setup.sh
```

---

## 🔧 Manual Installation (If Automated Setup Fails)

### Step 1: Verify Python Installation
```bash
# Check if Python 3.7+ is installed
python --version
# or
python3 --version

# If not installed:
# Windows: Download from https://www.python.org/downloads/
# macOS: brew install python@3.11
# Linux: sudo apt-get install python3.11
```

### Step 2: Install Required Packages
```bash
# Install test suite dependencies
pip install -r requirements.txt

# Or install individually:
pip install requests psutil packaging openpyxl pandas speedtest-cli
```

### Step 3: Verify Installation
```bash
# Test Python import
python -c "import openpyxl; print('✓ openpyxl installed')"
python -c "import pandas; print('✓ pandas installed')"
python -c "import psutil; print('✓ psutil installed')"
python -c "import requests; print('✓ requests installed')"
```

### Step 4: Run Tests
```bash
# Windows
python run_all_tests.py

# macOS/Linux
python3 run_all_tests.py
```

---

## 📋 Pre-Installation Checklist

Before running tests, ensure you have:

- [ ] **Windows 11 / macOS 12+ / Ubuntu 20.04+**
- [ ] **Python 3.7 or higher** installed and in PATH
- [ ] **pip** (Python package manager) working
- [ ] **16 GB RAM minimum** available
- [ ] **128 GB free disk space minimum**
- [ ] **Internet connection** for API testing
- [ ] **Administrator/sudo access** (for some checks)

---

## 🔍 Troubleshooting Installation

### Issue: "Python not found"
```bash
# Solution 1: Verify Python in PATH
# Windows:
where python

# macOS/Linux:
which python3

# Solution 2: Add Python to PATH
# Windows: See https://docs.python.org/3/using/windows.html#finding-the-python-executable
# macOS/Linux: Usually automatic during installation
```

### Issue: "pip not found"
```bash
# Solution: Use Python's pip module
python -m pip install -r requirements.txt

# Or upgrade pip first:
python -m pip install --upgrade pip
```

### Issue: "Permission denied" on setup.sh
```bash
# Solution: Make script executable
chmod +x setup.sh
./setup.sh
```

### Issue: "ModuleNotFoundError" when running tests
```bash
# Solution: Reinstall packages
pip install --force-reinstall -r requirements.txt

# Or try:
pip install -r requirements.txt --no-cache-dir
```

### Issue: "Connection timeout" for API tests
```bash
# Check internet connection
ping google.com

# If behind proxy:
pip install -r requirements.txt --proxy [user:passwd@]proxy.server:port

# Or test manually:
curl https://api.openai.com
```

### Issue: "Insufficient disk space"
```bash
# Check available space
# Windows: dir C:\
# macOS/Linux: df -h

# Free up space by:
# - Deleting temporary files
# - Clearing Python cache: pip cache purge
# - Removing unused applications
# - Then retry setup
```

---

## ✅ Post-Installation Verification

After installation, verify everything works:

```bash
# 1. Check all packages installed
pip list

# 2. Run a quick test
python -c "
import requests, psutil, openpyxl, pandas
print('✓ All core packages imported successfully')
print(f'✓ Python version: {__import__(\"sys\").version.split()[0]}')
print(f'✓ System RAM: {psutil.virtual_memory().total / (1024**3):.1f} GB')
"

# 3. Run the test suite
python run_all_tests.py
```

---

## 🌐 Network Configuration

### For Firewall/Proxy Users

If behind corporate firewall/proxy:

```bash
# Configure pip for proxy
pip install -r requirements.txt \
    --proxy [user:passwd@]proxy.server:port

# Or configure permanently in ~/.pip/pip.conf
[global]
proxy = [user:passwd@]proxy.server:port
```

### Firewall Rules Needed

Allow outbound access to:
- `*.openai.com` (OpenAI API)
- `*.anthropic.com` (Anthropic API)
- `*.github.com` (GitHub)
- `*.github.io` (GitHub Pages)
- `*.pypi.org` (Python packages)
- `*.npmjs.org` (Node packages)
- `*.docker.com` (Docker)

---

## 🔐 Security Best Practices

### 1. API Keys
Never commit API keys to git:
```bash
# Set environment variables instead
# Windows PowerShell:
$env:OPENAI_API_KEY = "your-key"
$env:ANTHROPIC_API_KEY = "your-key"

# macOS/Linux:
export OPENAI_API_KEY="your-key"
export ANTHROPIC_API_KEY="your-key"
```

### 2. File Permissions
```bash
# Make setup script executable (not world-writable)
chmod 755 setup.sh

# Restrict sensitive files
chmod 600 ~/.openai_key
chmod 600 ~/.anthropic_key
```

### 3. Python Virtual Environment
For isolation, use virtual environment:
```bash
# Create virtual environment
python -m venv venv

# Activate it
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

# Install requirements
pip install -r requirements.txt

# Run tests
python run_all_tests.py

# Deactivate when done
deactivate
```

---

## 📦 Dependency Details

### Required Packages

| Package | Version | Purpose |
|---------|---------|---------|
| `openpyxl` | ≥3.8.0 | Excel file creation |
| `pandas` | ≥1.5.0 | Data manipulation |
| `requests` | ≥2.28.0 | HTTP requests |
| `psutil` | ≥5.9.0 | System monitoring |
| `packaging` | ≥21.3 | Version comparison |
| `speedtest-cli` | ≥2.1.3 | Network bandwidth testing |

### Optional but Recommended

```bash
# For better development experience
pip install ipython jupyter

# For enhanced testing
pip install pytest pytest-cov
```

---

## 🎯 First Run Expectations

### Timeline
- **Installation**: 3-5 minutes
- **Test execution**: 5-15 minutes (depends on system and network)
- **Report generation**: 1-2 minutes
- **Total time**: 10-25 minutes

### Expected Output
```
✓ Core Software tests
✓ Python Libraries tests
✓ API Keys validation
✓ Hardware specifications
✓ Network connectivity
✓ VM Access verification
✓ Excel report generation
✓ Summary with recommendations
```

### Output Files
```
dependency_logs.json                    (JSON format - raw data)
Dependency_Test_Report.xlsx            (Excel - complete report)
README.md                              (This documentation)
```

---

## 📊 Understanding Your Report

After running, you'll get an Excel file with:

1. **Summary Tab** - Overall statistics
2. **Detailed Logs Tab** - Every test result
3. **Charts & Analytics Tab** - Visual charts
4. **Recommendations Tab** - Action items
5. **Hardware Details Tab** - System info

---

## 🔄 Re-running Tests

After fixing issues:

```bash
# Simply run again
python run_all_tests.py

# This will:
# - Re-test all dependencies
# - Generate new logs
# - Create updated Excel report
# - Show which issues are resolved
```

---

## 📞 Getting Help

### Check These First:
1. **README.md** - Complete documentation
2. **Troubleshooting section above** - Common issues
3. **Excel report** - Specific failure messages
4. **requirements.txt** - Available packages

### Still Have Issues?

1. **Check Python version**: `python --version`
2. **Verify pip works**: `pip --version`
3. **Test internet**: `ping google.com`
4. **Run with verbose output**: `python -u run_all_tests.py`
5. **Check disk space**: `df -h` (macOS/Linux) or `dir C:\` (Windows)

---

## 🎓 What's Next?

After successful installation:

1. ✅ Review the Excel report
2. ✅ Address any CRITICAL FAILURES (red)
3. ✅ Consider warnings (yellow)
4. ✅ Install remaining optional tools as needed
5. ✅ Configure API keys and Git
6. ✅ Proceed with development

---

## 📝 Configuration Examples

### Example 1: Windows PowerShell Setup
```powershell
# Navigate to scripts directory
cd C:\Users\YourName\Documents\test-scripts

# Install requirements
pip install -r requirements.txt

# Set API keys (optional)
$env:OPENAI_API_KEY = "sk-..."
$env:ANTHROPIC_API_KEY = "sk-..."

# Run tests
python run_all_tests.py
```

### Example 2: macOS Terminal Setup
```bash
# Navigate to scripts directory
cd ~/Documents/test-scripts

# Install requirements
pip3 install -r requirements.txt

# Set API keys (optional)
export OPENAI_API_KEY="sk-..."
export ANTHROPIC_API_KEY="sk-..."

# Run tests
python3 run_all_tests.py
```

### Example 3: Linux with Virtual Environment
```bash
# Navigate to scripts directory
cd ~/test-scripts

# Create virtual environment
python3 -m venv venv

# Activate it
source venv/bin/activate

# Install requirements
pip install -r requirements.txt

# Set API keys (optional)
export OPENAI_API_KEY="sk-..."
export ANTHROPIC_API_KEY="sk-..."

# Run tests
python run_all_tests.py

# Deactivate when done
deactivate
```

---

## ✅ Installation Checklist

- [ ] Downloaded all scripts
- [ ] Python 3.7+ installed
- [ ] Ran `pip install -r requirements.txt`
- [ ] All dependencies installed successfully
- [ ] Tests executed without errors
- [ ] Excel report generated
- [ ] Reviewed report for issues
- [ ] Addressed critical failures
- [ ] Ready to proceed

---

## 🚀 You're All Set!

Congratulations! Your development environment is now validated and ready for AI/ML work.

**Next steps:**
1. Review the Excel report
2. Follow the recommendations
3. Configure API keys
4. Start developing!

---

**Last Updated**: 2024
**Version**: 1.0
**Compatibility**: Python 3.7+, Windows 11, macOS 12+, Ubuntu 20.04+
