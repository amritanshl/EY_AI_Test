#!/usr/bin/env python3
"""
Master Dependency Test Runner
Executes all tests and generates comprehensive Excel report
"""

import subprocess
import sys
import os
from pathlib import Path

def run_test_suite():
    """Run complete dependency testing suite"""
    
    print("\n" + "="*70)
    print("DEPENDENCY TEST SUITE - COMPLETE INFRASTRUCTURE VALIDATION")
    print("="*70 + "\n")
    
    # Ensure output directory exists
    output_dir = Path('/mnt/user-data/outputs')
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Step 1: Run dependency tests
    print("[Step 1/3] Running dependency tests...\n")
    try:
        result = subprocess.run(
            [sys.executable, '/home/claude/test_dependencies.py'],
            capture_output=False,
            text=True
        )
        if result.returncode != 0:
            print("⚠ Warning: Some tests encountered issues")
    except Exception as e:
        print(f"✗ Error running tests: {e}")
        return False
    
    # Step 2: Generate Excel report
    print("\n[Step 2/3] Generating Excel report...\n")
    try:
        result = subprocess.run(
            [sys.executable, '/home/claude/generate_excel_report.py'],
            capture_output=False,
            text=True
        )
        if result.returncode != 0:
            print("⚠ Warning: Excel generation encountered issues")
    except Exception as e:
        print(f"✗ Error generating report: {e}")
        return False
    
    # Step 3: Generate summary
    print("\n[Step 3/3] Generating summary...\n")
    print("="*70)
    print("TEST SUITE COMPLETED")
    print("="*70)
    print("\nGenerated Files:")
    print(f"  ✓ Logs (JSON):        /mnt/user-data/outputs/dependency_logs.json")
    print(f"  ✓ Report (Excel):     /mnt/user-data/outputs/Dependency_Test_Report.xlsx")
    print("\nExcel Report Contents:")
    print(f"  • Summary            - Overall test statistics and metrics")
    print(f"  • Detailed Logs      - Complete log of all tests with status")
    print(f"  • Charts & Analytics - Visual representation of results")
    print(f"  • Recommendations    - Action items and configuration steps")
    print(f"  • Hardware Details   - System specifications and capabilities")
    print("\nNext Steps:")
    print("  1. Download the Excel file to review detailed results")
    print("  2. Address any CRITICAL FAILURES (marked in red)")
    print("  3. Install any missing dependencies listed in Recommendations")
    print("  4. Configure API keys and environment variables")
    print("  5. Re-run tests to verify fixes")
    print("\n" + "="*70 + "\n")
    
    return True

if __name__ == '__main__':
    success = run_test_suite()
    sys.exit(0 if success else 1)
