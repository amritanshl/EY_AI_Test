# Comprehensive Dependency Testing Suite
## AI/ML Development Environment Validation

---

## 📋 Overview

This testing suite provides **thorough validation** of all dependencies required for an AI/ML development environment. It tests:

- ✅ **Core Software** (Python, Node.js, Git, Docker, etc.)
- ✅ **Python Libraries** (LangChain, LangGraph, ChromaDB, FAISS, etc.)
- ✅ **API Keys & Subscriptions** (OpenAI, Anthropic, LangSmith, GitHub)
- ✅ **Hardware Specifications** (CPU, RAM, Storage, Network)
- ✅ **VM Access & Permissions** (Admin rights, File write access, Git config)
- ✅ **Network Connectivity** (API endpoints, DNS resolution, Bandwidth)

**Output**: Comprehensive Excel report with logs, charts, analytics, and actionable recommendations.

---

## 🚀 Quick Start

### Prerequisites
- Python 3.7+ already installed
- pip package manager available
- Internet connection for testing API connectivity

### Installation (5 minutes)

```bash
# 1. Navigate to your test directory
cd /path/to/test/directory

# 2. Install required Python packages
pip install requests psutil packaging openpyxl pandas speedtest-cli

# 3. Copy the test scripts (if not already present)
# - test_dependencies.py
# - generate_excel_report.py
# - run_all_tests.py

# 4. Run the complete test suite
python run_all_tests.py
```

---

## 📊 What Gets Tested

### 1. **Core Software**
```
✓ Python 3.11+
✓ Node.js v20+
✓ Git
✓ Docker
✓ pip
✓ Jupyter (optional)
✓ VS Code (optional)
✓ Postman (optional)
✓ Playwright (optional)
✓ MCP Inspector (optional)
```

### 2. **Python Libraries**
```
✓ langchain          ✓ pydantic
✓ langgraph          ✓ openai
✓ chromadb           ✓ anthropic
✓ faiss-cpu          ✓ langsmith
✓ sentence-transformers  ✓ crewai
✓ ragas              ✓ autogen
✓ promptfoo
✓ pytest
```

### 3. **API Connectivity**
```
✓ OpenAI API        (with credential validation)
✓ Anthropic API     (with credential validation)
✓ LangSmith API     (presence check)
✓ GitHub API        (presence check)
```

### 4. **Hardware Requirements**
```
✓ CPU Cores:        4+ cores (minimum)
✓ Memory:           16+ GB RAM (minimum)
✓ Storage:          128+ GB free (minimum)
✓ Network:          20+ Mbps (recommended)
✓ Platform:         Windows 11, macOS, or Linux
```

### 5. **VM Access & Security**
```
✓ Administrator Rights
✓ File Write Permissions
✓ Git Configuration
✓ Internet Access
```

---

## 🎯 Running the Tests

### Option 1: Full Test Suite (Recommended)
```bash
python run_all_tests.py
```
This runs all tests and generates the Excel report in one command.

### Option 2: Individual Test Script
```bash
# Run just the dependency tests
python test_dependencies.py

# This generates: dependency_logs.json
```

### Option 3: Generate Report Only
```bash
# If you already have dependency_logs.json
python generate_excel_report.py
```

### Option 4: Manual Setup & Configuration

```bash
# Step 1: Test dependencies
python test_dependencies.py

# Check the output for any failures
# Output: dependency_logs.json

# Step 2: Generate Excel report
python generate_excel_report.py

# Output: Dependency_Test_Report.xlsx
```

---

## 📈 Excel Report Structure

### Sheet 1: **Summary**
- Overall test statistics
- Pass/Fail/Warning counts
- Success rate percentage
- Category-by-category breakdown

### Sheet 2: **Detailed Logs**
- Complete log of every test
- Timestamp, category, item, status, message, details
- Color-coded by status (Green=Pass, Red=Fail, Yellow=Warn)
- Fully searchable and sortable

### Sheet 3: **Charts & Analytics**
- **Pie Chart**: Test status distribution
- **Bar Chart**: Results by category
- Visual analytics for quick assessment

### Sheet 4: **Recommendations**
- List of critical failures
- List of warnings
- 8-step remediation guide
- Configuration instructions

### Sheet 5: **Hardware Details**
- CPU specifications
- Memory information
- Storage capacity
- Platform details

---

## 🔧 Understanding Results

### Status Indicators

| Status | Meaning | Action |
|--------|---------|--------|
| **✓ PASS** | Working correctly | ✅ No action needed |
| **✗ FAIL** | Critical issue | ⚠️ Must fix immediately |
| **⚠ WARN** | Non-critical issue | 🔍 Review and consider fixing |

### Color Coding
- 🟢 **Green**: Test passed - all good
- 🔴 **Red**: Test failed - immediate action required
- 🟡 **Yellow**: Warning - review recommended

---

## 🛠️ Fixing Common Issues

### Issue 1: Python Version Too Old
```bash
# Check current version
python --version

# Install Python 3.11+
# Windows: Download from python.org
# macOS: brew install python@3.11
# Linux: sudo apt-get install python3.11
```

### Issue 2: Missing Python Libraries
```bash
# Install all required libraries at once
pip install langchain langgraph chromadb faiss-cpu \
    sentence-transformers ragas promptfoo pytest \
    pydantic openai anthropic langsmith crewai autogen
```

### Issue 3: API Keys Not Configured
```bash
# Set environment variables (Windows - PowerShell)
$env:OPENAI_API_KEY = "your-key-here"
$env:ANTHROPIC_API_KEY = "your-key-here"
$env:LANGSMITH_API_KEY = "your-key-here"

# macOS/Linux
export OPENAI_API_KEY="your-key-here"
export ANTHROPIC_API_KEY="your-key-here"
export LANGSMITH_API_KEY="your-key-here"
```

### Issue 4: Insufficient Disk Space
```bash
# Check current disk usage
# Windows: dir C:\
# macOS/Linux: df -h

# Free up space:
# Delete temporary files, caches, old installations
# Or expand disk capacity
```

### Issue 5: Git Not Configured
```bash
# Configure Git
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"

# Verify
git config --list
```

### Issue 6: Docker Not Working
```bash
# Install Docker Desktop
# Download from: docker.com

# Verify installation
docker --version
docker run hello-world
```

### Issue 7: Admin Rights Missing
```bash
# Windows: Run PowerShell as Administrator
# Then execute test script

# Linux: May need sudo (but not recommended)
# Try: python test_dependencies.py
```

---

## 📋 Hardware Requirements Checklist

### Minimum Recommended Setup
```
CPU:       4-core processor (Intel i5 equivalent or better)
Memory:    16 GB RAM
Storage:   128 GB SSD free space
Network:   20 Mbps stable connection
OS:        Windows 11 / macOS 12+ / Ubuntu 20.04+
```

### Optimal Setup for AI/ML Work
```
CPU:       8-core processor (Intel i7/i9 or AMD Ryzen 7/9)
Memory:    32-64 GB RAM
Storage:   256 GB+ SSD free space
GPU:       NVIDIA GPU with CUDA support (optional but recommended)
Network:   100+ Mbps stable connection
OS:        Windows 11 / macOS 13+ / Ubuntu 22.04+
```

---

## 🌐 Network Requirements

### Outbound Access Needed
The following domains must be accessible (no firewall blocks):

```
API Endpoints:
  • api.openai.com              (OpenAI API)
  • api.anthropic.com           (Anthropic API)
  • api.github.com              (GitHub API)
  • api.smith.langchain.com    (LangSmith)

Package Registries:
  • pypi.org                    (Python packages)
  • registry.npmjs.org          (Node packages)
  • index.crates.io             (Rust packages)

Container Registries:
  • registry.hub.docker.com     (Docker Hub)
  • ghcr.io                     (GitHub Container Registry)
```

### Bandwidth Recommendation
- **Minimum**: 10 Mbps (will work but slow)
- **Recommended**: 20+ Mbps (good for most work)
- **Optimal**: 100+ Mbps (professional development)

---

## 🔐 Security Considerations

### API Keys
- ✅ Store in environment variables (NOT in code)
- ✅ Use separate keys for dev/prod
- ✅ Rotate keys regularly
- ✅ Never commit keys to version control

### File Permissions
- ✅ Ensure proper file access on multi-user systems
- ✅ Use .gitignore for sensitive files
- ✅ Set appropriate SSH key permissions (600)

### Network Security
- ✅ Use VPN if accessing from public networks
- ✅ Keep firewall rules up to date
- ✅ Monitor API usage for unusual activity

---

## 📊 Interpreting the Report

### Success Rate > 90%
✅ **Status**: Ready for production
- Minor warnings don't affect core functionality
- Can proceed with development

### Success Rate 70-90%
⚠️ **Status**: Mostly ready, review warnings
- Address warnings before critical work
- Verify functionality for your use case

### Success Rate < 70%
❌ **Status**: Not ready, fix failures first
- Critical issues must be resolved
- Follow recommendations in remediation section

---

## 🔄 Re-running Tests

After fixing issues, you can:

```bash
# Re-run complete test suite
python run_all_tests.py

# This will:
# 1. Test all dependencies again
# 2. Generate updated logs
# 3. Create new Excel report with latest results

# Compare new results with previous report to verify fixes
```

---

## 💡 Tips & Tricks

### 1. **Automate Environment Setup**
```bash
# Create setup script for reproducibility
# setup.sh (macOS/Linux)
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python run_all_tests.py
```

### 2. **Batch Testing Multiple Machines**
```bash
# Run on each machine and collect reports
# Compare results to ensure consistency
```

### 3. **Track History**
```bash
# Save reports with timestamps
cp Dependency_Test_Report.xlsx reports/Report_$(date +%Y%m%d_%H%M%S).xlsx
```

### 4. **Continuous Monitoring**
```bash
# Schedule periodic tests
# Windows: Task Scheduler
# macOS/Linux: cron jobs
# Run weekly to catch issues early
```

---

## 🐛 Troubleshooting

### Script Won't Run
```bash
# Verify Python is installed
python --version

# Check if packages are installed
pip list | grep -E "openpyxl|pandas|requests"

# Run with verbose output
python -u run_all_tests.py
```

### Permission Denied Error
```bash
# Make script executable (macOS/Linux)
chmod +x *.py

# Run with Python explicitly
python run_all_tests.py
```

### Import Errors
```bash
# Ensure all packages installed
pip install requests psutil packaging openpyxl pandas speedtest-cli

# If still failing, upgrade pip
pip install --upgrade pip
```

### Network Test Fails
```bash
# Check internet connection
ping google.com

# Check if proxy is required
# If behind corporate proxy, set it:
pip install --proxy [user:passwd@]proxy.server:port

# Test specific API endpoint
curl -I https://api.openai.com
```

### Excel File Corruption
```bash
# Re-generate report
python generate_excel_report.py

# If logs are lost, re-run tests
python test_dependencies.py
python generate_excel_report.py
```

---

## 📞 Support & Documentation

### Getting Help
1. **Review the recommendations** in the Excel report
2. **Check this README** for common issues
3. **Verify hardware** meets minimum requirements
4. **Check network connectivity** to API endpoints

### Additional Resources
- [Python Official Docs](https://docs.python.org/)
- [OpenAI API Docs](https://platform.openai.com/docs/)
- [Anthropic API Docs](https://docs.anthropic.com/)
- [Docker Documentation](https://docs.docker.com/)
- [Git Documentation](https://git-scm.com/doc)

---

## 📝 License & Terms

This testing suite is provided as-is for infrastructure validation and dependency verification.

**Disclaimer**: Results are based on current system state. Some tests require internet connectivity and valid API credentials.

---

## 🎓 Version History

**Version 1.0** - Initial Release
- Complete dependency testing
- Excel report generation
- Hardware validation
- API connectivity checks
- Comprehensive recommendations

---

## 📅 Last Updated
**Generated**: 2024
**Compatibility**: Python 3.7+, Windows 11, macOS 12+, Ubuntu 20.04+

---

## ✅ Quick Validation Checklist

After running tests, verify:

- [ ] All core software installed
- [ ] Python libraries installed
- [ ] API keys configured (if available)
- [ ] Hardware meets minimum specs
- [ ] Network connectivity working
- [ ] Admin rights available
- [ ] Git configured
- [ ] Excel report generated successfully
- [ ] No critical failures in report
- [ ] Ready to proceed with development

---

**Happy Testing! 🚀**
