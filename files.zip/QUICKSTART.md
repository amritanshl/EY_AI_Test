# Quick Start Guide
## Get Your Infrastructure Tested in 5 Minutes

---

## 🚀 TL;DR (Too Long; Didn't Read)

### Windows Users:
```cmd
setup.bat
```

### macOS/Linux Users:
```bash
chmod +x setup.sh
./setup.sh
```

Done! Check `Dependency_Test_Report.xlsx` for results.

---

## 📦 What's in the Package?

```
test_dependencies.py          - Core testing engine
generate_excel_report.py      - Excel report builder
run_all_tests.py              - Master orchestrator
requirements.txt              - Package list
setup.bat                     - Windows setup
setup.sh                       - macOS/Linux setup
README.md                      - Full documentation
INSTALL.md                     - Installation guide
QUICKSTART.md                  - This file
```

---

## ⚡ Installation

### Option 1: Automated (Recommended)

**Windows:**
```cmd
setup.bat
```

**macOS/Linux:**
```bash
chmod +x setup.sh
./setup.sh
```

### Option 2: Manual

```bash
# Install dependencies
pip install -r requirements.txt

# Run tests
python run_all_tests.py
```

---

## ✅ What Gets Tested

- ✓ Python 3.11+, Node.js, Git, Docker
- ✓ LangChain, LangGraph, ChromaDB, FAISS, etc.
- ✓ OpenAI, Anthropic, LangSmith API keys
- ✓ CPU, RAM, Storage, Network
- ✓ Admin rights, Git config, File permissions
- ✓ Network connectivity to all major endpoints

---

## 📊 Sample Report

You'll get an Excel file with:

| Sheet | Contains |
|-------|----------|
| Summary | Test statistics |
| Detailed Logs | Every test result |
| Charts | Visual analytics |
| Recommendations | What to fix |
| Hardware Details | System specs |

---

## 🔧 Typical Issues & Fixes

### Python Not Found
```bash
# Download from python.org (Windows)
# Or: brew install python@3.11 (macOS)
# Or: apt-get install python3.11 (Linux)
```

### Missing Libraries
```bash
pip install -r requirements.txt
```

### Network Issues
```bash
# Check connection
ping google.com

# Or test API
curl https://api.openai.com
```

### Permission Denied (macOS/Linux)
```bash
chmod +x setup.sh
./setup.sh
```

---

## 📈 Reading Your Results

### Color Coding
- 🟢 **Green** = Pass ✓
- 🔴 **Red** = Fail ✗
- 🟡 **Yellow** = Warning ⚠

### Success Rate
- **>90%** = Ready to go
- **70-90%** = Review warnings
- **<70%** = Fix issues first

---

## 🎯 Common Use Cases

### Case 1: Fresh Setup
```bash
python run_all_tests.py
# Review report → Install missing tools → Re-run
```

### Case 2: Verify After Install
```bash
python run_all_tests.py
# Should show all tests passing
```

### Case 3: Troubleshoot Issues
```bash
python test_dependencies.py
# Review detailed logs in Excel
# Fix issues → Re-run
```

### Case 4: Team Validation
```bash
# Run on each machine
python run_all_tests.py

# Collect all reports
# Compare to ensure consistency
```

---

## 🔐 API Keys (Optional)

For API testing, set environment variables:

**Windows PowerShell:**
```powershell
$env:OPENAI_API_KEY = "sk-..."
$env:ANTHROPIC_API_KEY = "sk-..."
python run_all_tests.py
```

**macOS/Linux:**
```bash
export OPENAI_API_KEY="sk-..."
export ANTHROPIC_API_KEY="sk-..."
python run_all_tests.py
```

---

## 📋 Requirements

| Item | Minimum | Recommended |
|------|---------|-------------|
| Python | 3.7+ | 3.11+ |
| RAM | 8 GB | 16+ GB |
| Storage | 50 GB | 128+ GB |
| Network | 10 Mbps | 20+ Mbps |
| OS | Windows 10 | Windows 11 |

---

## 🚀 Next Steps

1. ✅ Run setup script
2. ✅ Wait for tests to complete
3. ✅ Open Excel report
4. ✅ Review critical failures (red)
5. ✅ Follow recommendations
6. ✅ Re-run to verify fixes

---

## 📞 Help

**Issue Not Listed?**
- See README.md for detailed docs
- Check INSTALL.md for setup help
- Review Excel report for specific errors

---

## ✨ That's It!

Your infrastructure is now validated. Happy coding! 🎉

---

**Version**: 1.0 | **Python**: 3.7+ | **Updated**: 2024
