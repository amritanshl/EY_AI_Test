@echo off
REM Dependency Testing Suite - Automated Setup
REM For Windows PowerShell

echo.
echo ============================================================
echo  Dependency Testing Suite - Setup Script
echo ============================================================
echo.

REM Check if Python is installed
echo [1/4] Checking Python installation...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Python not found in PATH
    echo Please install Python 3.11+ from https://www.python.org/
    echo Make sure to check "Add Python to PATH" during installation
    pause
    exit /b 1
)
python --version
echo.

REM Upgrade pip
echo [2/4] Upgrading pip...
python -m pip install --upgrade pip
if %errorlevel% neq 0 (
    echo WARNING: Could not upgrade pip, continuing anyway...
)
echo.

REM Install requirements
echo [3/4] Installing required Python packages...
pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo ERROR: Failed to install requirements
    pause
    exit /b 1
)
echo.

REM Run tests
echo [4/4] Running dependency tests...
python run_all_tests.py

echo.
echo ============================================================
echo  Setup Complete!
echo ============================================================
echo.
echo The Excel report should be available at:
echo   Dependency_Test_Report.xlsx
echo.
echo For detailed instructions, see README.md
echo.
pause
